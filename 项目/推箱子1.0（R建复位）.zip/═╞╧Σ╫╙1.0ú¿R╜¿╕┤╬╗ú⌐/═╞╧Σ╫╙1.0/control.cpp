#pragma once
/*
Ӧ�ã������Ӽ��װ�
���ߣ�zero - ���ꡢzero - ���ߡ�zero_Justdoit
*/
#include <iostream>
using namespace std;
#include "control.h"
#include <conio.h>
#include "public.h"
//#include <time.h>
int	map[5][20][22] =
{
	{
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0},
		{0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0},
		{0, 0, 0, 0, 1, 1, 8, 0, 2, 2, 3, 3, 3, 3, 3, 3, 1, 1, 0, 0, 0, 0},
		{0, 0, 0, 0, 1, 1, 0, 0, 2, 2, 3, 3, 3, 3, 3, 3, 1, 1, 0, 0, 0, 0},
		{0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
		{0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
		{0, 0, 1, 1, 1, 1, 1, 1, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0},
		{0, 0, 1, 1, 1, 1, 1, 1, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0},
		{0, 0, 1, 1, 0, 0, 0, 0, 8, 0, 1, 1, 4, 4, 1, 1, 0, 0, 1, 1, 0, 0},
		{0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 4, 4, 1, 1, 0, 0, 1, 1, 0, 0},
		{0, 0, 1, 1, 8, 0, 4, 4, 0, 0, 1, 1, 9, 0, 0, 0, 0, 0, 1, 1, 0, 0},
		{0, 0, 1, 1, 0, 0, 4, 4, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0},
		{0, 0, 1, 1, 0, 0, 9, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
		{0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
		{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
	},//��һ��
	{
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 1, 1, 2, 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 1, 1, 2, 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 1, 1, 8, 0, 4, 4, 4, 4, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0},
		{0, 0, 1, 1, 0, 0, 4, 4, 4, 4, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0},
		{0, 0, 1, 1, 9, 0, 4, 4, 8, 0, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 0, 0},
		{0, 0, 1, 1, 0, 0, 4, 4, 0, 0, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 0, 0},
		{0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 3, 3, 1, 1, 0, 0},
		{0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 3, 3, 1, 1, 0, 0},
		{0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 1, 1, 0, 0},
		{0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 1, 1, 0, 0},
		{0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 9, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0},
		{0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0},
		{0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
		{0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
	},//�ڶ���
	{
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
		0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
		0, 0, 0, 0, 1, 1, 1, 1, 8, 0, 0, 0, 1, 1, 0, 0, 2, 2, 1, 1, 0, 0,
		0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 2, 2, 1, 1, 0, 0,
		0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0,
		0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0,
		0, 0, 0, 0, 1, 1, 4, 4, 0, 0, 4, 4, 0, 0, 4, 4, 0, 0, 1, 1, 0, 0,
		0, 0, 0, 0, 1, 1, 4, 4, 0, 0, 4, 4, 0, 0, 4, 4, 0, 0, 1, 1, 0, 0,
		0, 0, 0, 0, 1, 1, 0, 0, 4, 4, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0,
		0, 0, 0, 0, 1, 1, 0, 0, 4, 4, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0,
		1, 1, 1, 1, 1, 1, 0, 0, 4, 4, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0,
		1, 1, 1, 1, 1, 1, 0, 0, 4, 4, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0,
		1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 9, 0, 0, 0, 1, 1, 0, 0, 0, 0,
		1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0,
		1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
		1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
	},//������
	{
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
		{1, 1, 1, 1, 3, 3, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
		{1, 1, 1, 1, 3, 3, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
		{1, 1, 9, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
		{1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
		{1, 1, 0, 0, 1, 1, 4, 4, 4, 4, 4, 4, 8, 0, 3, 3, 1, 1, 0, 0},
		{1, 1, 0, 0, 1, 1, 4, 4, 4, 4, 4, 4, 0, 0, 3, 3, 1, 1, 0, 0},
		{1, 1, 3, 3, 4, 4, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 1, 1, 0, 0},
		{1, 1, 3, 3, 4, 4, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 1, 1, 0, 0},
		{1, 1, 0, 0, 1, 1, 4, 4, 4, 4, 4, 4, 8, 0, 3, 3, 1, 1, 0, 0},
		{1, 1, 0, 0, 1, 1, 4, 4, 4, 4, 4, 4, 0, 0, 3, 3, 1, 1, 0, 0},
		{1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
		{1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
		{1, 1, 1, 1, 3, 3, 8, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
		{1, 1, 1, 1, 3, 3, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
	},//���Ĺ�
	{
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0,
		1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 1, 1, 1, 1, 3, 3, 0, 0, 0, 0, 9, 0, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 1, 1, 1, 1, 3, 3, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 3, 3, 1, 1, 0, 0, 1, 1, 4, 4, 0, 0, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 3, 3, 1, 1, 0, 0, 1, 1, 4, 4, 0, 0, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 3, 3, 0, 0, 4, 4, 2, 2, 4, 4, 4, 4, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 3, 3, 0, 0, 4, 4, 2, 2, 4, 4, 4, 4, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 0, 0, 1, 1, 1, 1, 4, 4, 4, 4, 0, 0, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 0, 0, 1, 1, 1, 1, 4, 4, 4, 4, 0, 0, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 9, 0, 0, 0, 0, 0, 8, 0, 0, 0, 3, 3, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,0, 0,
		1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0,
	}
};//�����
int  map_R[20][22] =
{
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0},
	{0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0},
	{0, 0, 0, 0, 1, 1, 8, 0, 2, 2, 3, 3, 3, 3, 3, 3, 1, 1, 0, 0, 0, 0},
	{0, 0, 0, 0, 1, 1, 0, 0, 2, 2, 3, 3, 3, 3, 3, 3, 1, 1, 0, 0, 0, 0},
	{0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
	{0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
	{0, 0, 1, 1, 1, 1, 1, 1, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0},
	{0, 0, 1, 1, 1, 1, 1, 1, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0},
	{0, 0, 1, 1, 0, 0, 0, 0, 8, 0, 1, 1, 4, 4, 1, 1, 0, 0, 1, 1, 0, 0},
	{0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 4, 4, 1, 1, 0, 0, 1, 1, 0, 0},
	{0, 0, 1, 1, 8, 0, 4, 4, 0, 0, 1, 1, 9, 0, 0, 0, 0, 0, 1, 1, 0, 0},
	{0, 0, 1, 1, 0, 0, 4, 4, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0},
	{0, 0, 1, 1, 0, 0, 9, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
	{0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
	{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};
//����������λmap��
int map_Z[20][22];//������������map��
int map_m[20][22];//ִ����Ч���ص��н�洢����
bool recall = true;//�жϳ���
int posx, posy;//��������±꣬���±�
int flagX, flagY;//����ԭʼ����
int time = 0;//�Ʋ�
int scores = 0;
int level = 0;
int flag = 0;
void draw()//��ͼ 0�յأ�1ǽ��2�ˣ�3�ɹ��㣬4����
{
	//����
	//system("CLS");
	
	SetCursors(0, 0);//�������ã���������̫����
	cout << "����������" << endl;
	SetCursors(0, 1);//�������ã�����
	cout << "                      ";
	SetCursors(0, 1);
	cout << "��ǰ����Ϊ" << scores << endl;
	
	for (int i = 0; i < 20; i++)
	{
		for (int j = 0; j < 22; j++)
		{
			if (flag == 1)
			{
				if (map_m[i][j] == map[level][i][j])
				{
					continue;//ֻ��ʾ�ı��Ԫ��
				}
			}
			
			//j--�У�i--��
			SetCursors(j*2, i + 2);//�ص�λ���������Ϊ�������ַ�������J*2
			switch (map[level][i][j])
			{
			case space:
				cout << "  "; break;//�յ�
			case wall:
				cout << "��"; break;//ǽ
			case hum://��
			case winhum://5
				cout << "��"; break;//2 ->��,5->����ɹ���ļ���
			case win:
				cout << "��"; break;//�ɹ���
			case box://����
			case winbox:
			{
				//int  fgColor = rand() % 6 + 4;
				setColor(6, 14);//��ɫ
				cout << "��"; //������ɹ���ļ���
				setColor(2, 14);//ԭ����̨��ɫ
				break;
			}
				
			case cakes:
				cout << "��"; break;//**************************************����
			case bomb:
				cout << "ը"; break;//**************************************ը��

			default: break;
			}
		}
		cout << endl;
	}
	if (flag == 0)
	{
		flag = 1;
	}
	
	cout << "�밴WASD���������ҿ��������ƶ�" << endl;
}

void getPos()//��ȡ��������
{
	for (int i = 0; i < 20; i++)
	{
		for (int j = 0; j < 22; j++)
		{
			if (hum == map[level][i][j] || winhum == map[level][i][j])
			{
				posx = i;
				posy = j;
				return;
			}
		}
	}
}

void MoveLogic(int a, int b)
{
	if (cakes == map[level][posx + a][posy + b])//******************************************�����������Ե����⣬�ӷ�
	{
		scores += 8;
		map[level][posx + a][posy + b] = 0;

	}
	if (bomb == map[level][posx + a][posy + b])//****************************************������ը���󣬱�ը�ˣ�����
	{
		scores -= 5;
		map[level][posx + a][posy + b] = 0;

	}

	//�������ǰ���ǿյ�
	if (space == map[level][posx + a][posy + b])
	{
		//��������ڳɹ�����
		if (winhum == map[level][posx][posy])
		{
			//�˸�Ϊ�ɹ���
			map[level][posx][posy] = win;
			map[level][posx + 1][posy] = win;
			map[level][posx][posy + 1] = win;
			map[level][posx + 1][posy + 1] = win;
			//�ɹ����Ϊ��
			map[level][posx + a][posy + b] = hum;
			map[level][posx + a + 1][posy + b] = hum;
			map[level][posx + a][posy + b + 1] = hum;
			map[level][posx + a + 1][posy + b + 1] = hum;
			posx += a;
			posy += b;
		}
		//������ﲻ�ڳɹ�����
		else
		{
			//�˸�Ϊ�յ�
			map[level][posx][posy] = space;
			map[level][posx +1][posy] = space;
			map[level][posx][posy + 1] = space;
			map[level][posx + 1][posy + 1] = space;
			//�յظ�Ϊ��
			map[level][posx + a][posy + b] = hum;
			map[level][posx + a + 1][posy + b] = hum;
			map[level][posx + a][posy + b + 1] = hum;
			map[level][posx + a + 1][posy + b+1] = hum;
			posx += a;
			posy += b;
		}
	}
	//�������ǰ��������
	else if (box == map[level][posx + a][posy + b])
	{
		//�������ǰ���ǵ���
		if (cakes == map[level][posx + 2 * a][posy + 2 * b])
		{
			map[level][posx + 2 * a][posy + 2 * b] = 0;//***************************************�����Ƶ�����λ�ã����ⱻ������ʧ�����ӷ�
		}
		if (bomb == map[level][posx + 2 * a][posy + 2 * b])
		{
			map[level][posx + 2 * a][posy + 2 * b] = 0;//**************************************�����Ƶ������ӷ�
			scores -= 5;//����ը������
		}

		//�������ǰ���ǿյ�
		if (space == map[level][posx + 2 * a][posy + 2 * b])
		{
			//��������ڳɹ�����
			if (winhum == map[level][posx][posy])
			{
				//�˱�ɹ���
				map[level][posx][posy] = win;
				map[level][posx + 1][posy] = win;
				map[level][posx][posy + 1] = win;
				map[level][posx + 1][posy + 1] = win;
				//���ӱ���
				map[level][posx + a][posy + b] = hum;
				map[level][posx + a + 1][posy + b] = hum;
				map[level][posx + a][posy + b + 1] = hum;
				map[level][posx + a+1][posy + b+1] = hum;
				//�յر�����
				map[level][posx + 2 * a][posy + 2 * b] = box;
				map[level][posx + 2 * a + 1][posy + 2 * b] = box;
				map[level][posx + 2 * a][posy + 2 * b + 1] = box;
				map[level][posx + 2 * a +1][posy + 2 * b + 1] = box;
				posx += a;
				posy += b;
			}
			//������ﲻ�ڳɹ�����
			else
			{
				//�յر������
				map[level][posx + 2 * a][posy + 2 * b] = box;
				map[level][posx + 2 * a + 1][posy + 2 * b] = box;
				map[level][posx + 2 * a][posy + 2 * b + 1] = box;
				map[level][posx + 2 * a + 1][posy + 2 * b + 1] = box;
				//���ӱ����
				map[level][posx + a][posy + b] = hum;
				map[level][posx + a+1][posy + b] = hum;
				map[level][posx + a][posy + b + 1] = hum;
				map[level][posx + a + 1][posy + b + 1] = hum;
				//�˱�յ�
				map[level][posx][posy] = space;
				map[level][posx + 1][posy] = space;
				map[level][posx][posy + 1] = space;
				map[level][posx + 1][posy + 1] = space;
				posx += a;
				posy += b;
			}
		}
		//�������ǰ���ǳɹ���
		else if (win == map[level][posx + 2 * a][posy + 2 * b])
		{
			//��������ڳɹ�����
			if (winhum == map[level][posx][posy])
			{
				//�˱�ɹ���
				map[level][posx][posy] = win;
				map[level][posx+1][posy] = win;
				map[level][posx][posy+1] = win;
				map[level][posx+1][posy+1] = win;
				//���ӱ���
				map[level][posx + a][posy + b] = hum;
				map[level][posx + a+1][posy + b] = hum;
				map[level][posx + a][posy + b+1] = hum;
				map[level][posx + a+1][posy + b+1] = hum;
				//�ɹ����������ɹ���ļ���
				map[level][posx + 2 * a][posy + 2 * b] = winbox;
				map[level][posx + 2 * a+1][posy + 2 * b] = winbox;
				map[level][posx + 2 * a][posy + 2 * b+1] = winbox;
				map[level][posx + 2 * a+1][posy + 2 * b+1] = winbox;
				posx += a;
				posy += b;
			}
			//������ﲻ�ڳɹ�����
			else
			{
				//�˱�ɿյ�
				map[level][posx][posy] = space;
				map[level][posx + 1][posy] = space;
				map[level][posx][posy + 1] = space;
				map[level][posx + 1][posy + 1] = space;
				//���ӱ���
				map[level][posx + a][posy + b] = hum;
				map[level][posx + a + 1][posy + b] = hum;
				map[level][posx + a][posy + b + 1] = hum;
				map[level][posx + a + 1][posy + b + 1] = hum;
				//�ɹ����������ɹ���ļ���
				map[level][posx + 2 * a][posy + 2 * b] = winbox;
				map[level][posx + 2 * a + 1][posy + 2 * b] = winbox;
				map[level][posx + 2 * a][posy + 2 * b + 1] = winbox;
				map[level][posx + 2 * a + 1][posy + 2 * b + 1] = winbox;
				posx += a;
				posy += b;
			}
		}
	}
	//�������ǰ���ǳɹ���
	else if (win == map[level][posx + a][posy + b])
	{
		//�������ǰ���ǳɹ��������ڳɹ�����
		if (winhum == map[level][posx][posy])
		{
			//�˱�ɹ���
			map[level][posx][posy] = win;
			map[level][posx + 1][posy] = win;
			map[level][posx][posy + 1] = win;
			map[level][posx + 1][posy + 1] = win;
			//�ɹ������
			map[level][posx + a][posy + b] = winhum;
			map[level][posx + a + 1][posy + b] = winhum;
			map[level][posx + a][posy + b + 1] = winhum;
			map[level][posx + a + 1][posy + b + 1] = winhum;
			posx += a;
			posy += b;
		}
		else
		{
			//�˱�յ�
			map[level][posx][posy] = space;
			map[level][posx + 1][posy] = space;
			map[level][posx][posy + 1] = space;
			map[level][posx + 1][posy + 1] = space;
			//�ɹ������
			map[level][posx + a][posy + b] = winhum;
			map[level][posx + a + 1][posy + b] = winhum;
			map[level][posx + a][posy + b + 1] = winhum;
			map[level][posx + a + 1][posy + b + 1] = winhum;
			posx += a;
			posy += b;
		}
	}
	//�������ǰ���ǳɹ�������ӵļ���
	else if (winbox == map[level][posx + a][posy + b])
	{
		//����ɹ�������ӵļ��ϵ�ǰ���ǿյ�
		if (space == map[level][posx + 2 * a][posy + 2 * b])
		{
			//��������ڳɹ�����
			if (winhum == map[level][posx][posy])
			{
				//�յر�����
				map[level][posx + 2 * a][posy + 2 * b] = box;
				map[level][posx + 2 * a + 1][posy + 2 * b] = box;
				map[level][posx + 2 * a][posy + 2 * b + 1] = box;
				map[level][posx + 2 * a + 1][posy + 2 * b + 1] = box;
				//�ɹ�������ӵļ��ϱ�ɹ������˵ļ���
				map[level][posx + a][posy + b] = winhum;
				map[level][posx + a + 1][posy + b] = winhum;
				map[level][posx + a][posy + b + 1] = winhum;
				map[level][posx + a + 1][posy + b + 1] = winhum;
				//�ɹ������˵ļ��ϱ�ɹ���
				map[level][posx][posy] = win;
				map[level][posx + 1][posy] = win;
				map[level][posx][posy + 1] = win;
				map[level][posx + 1][posy + 1] = win;
				posx += a;
				posy += b;
			}
			//������ﲻ�ڳɹ�����
			else
			{
				//�յر�����
				map[level][posx + 2 * a][posy + 2 * b] = box;
				map[level][posx + 2 * a + 1][posy + 2 * b] = box;
				map[level][posx + 2 * a][posy + 2 * b + 1] = box;
				map[level][posx + 2 * a + 1][posy + 2 * b + 1] = box;
				//�ɹ�������ӵļ��ϱ�ɹ������˵ļ���
				map[level][posx + a][posy + b] = winhum;
				map[level][posx + a + 1][posy + b] = winhum;
				map[level][posx + a][posy + b + 1] = winhum;
				map[level][posx + a + 1][posy + b + 1] = winhum;
				//�ɹ������˵ļ��ϱ�յ�
				map[level][posx][posy] = space;
				map[level][posx + 1][posy] = space;
				map[level][posx][posy + 1] = space;
				map[level][posx + 1][posy + 1] = space;
				posx += a;
				posy += b;
			}
		}
		//����ɹ�������ӵļ��ϵ�ǰ���ǳɹ���
		else if (win == map[level][posx + 2 * a][posy + 2 * b])
		{
			//��������ڳɹ�����
			if (winhum == map[level][posx][posy])
			{
				//�ɹ����ɹ�������ӵļ���
				map[level][posx + 2 * a][posy + 2 * b] = winbox;
				map[level][posx + 2 * a + 1][posy + 2 * b] = winbox;
				map[level][posx + 2 * a][posy + 2 * b + 1] = winbox;
				map[level][posx + 2 * a + 1][posy + 2 * b + 1] = winbox;
				//�ɹ�������ӵļ��ϱ�ɹ������˵ļ���
				map[level][posx + a][posy + b] = winhum;
				map[level][posx + a + 1][posy + b] = winhum;
				map[level][posx + a][posy + b + 1] = winhum;
				map[level][posx + a + 1][posy + b + 1] = winhum;
				//�ɹ������˵ļ��ϱ�ɹ���
				map[level][posx][posy] = win;
				map[level][posx + 1][posy] = win;
				map[level][posx][posy + 1] = win;
				map[level][posx + 1][posy + 1] = win;
				posx += a;
				posy += b;
			}
			//������ﲻ�ڳɹ�����
			else
			{
				////�ɹ����ɹ�������ӵļ���
				
				map[level][posx + 2 * a][posy + 2 * b] = winbox;
				map[level][posx + 2 * a + 1][posy + 2 * b] = winbox;
				map[level][posx + 2 * a][posy + 2 * b + 1] = winbox;
				map[level][posx + 2 * a + 1][posy + 2 * b + 1] = winbox;
				//�ɹ�������ӵļ��ϱ�ɹ������˵ļ���
				map[level][posx + a][posy + b] = winhum;
				map[level][posx + a + 1][posy + b] = winhum;
				map[level][posx + a][posy + b + 1] = winhum;
				map[level][posx + a + 1][posy + b + 1] = winhum;
				//�ɹ������˵ļ��ϱ�յ�
				map[level][posx][posy] = space;
				map[level][posx + 1][posy] = space;
				map[level][posx][posy + 1] = space;
				map[level][posx + 1][posy + 1] = space;
				posx += a;
				posy += b;
			}
		}
	}
	if (flagX != posx || flagY != posy)//������δ�ı䣬���ܳ���
		recall = false;
}
//�����ƶ�
bool move()
{
	char key = _getch();
	if (key == 'q' || key == 'Q')//�˳�
		return true;
	for (int i = 0; i < 20; i++)
	{
		for (int j = 0; j < 22; j++)
		{
			map_m[i][j] = map[level][i][j];//����ԭ��ͼ������ʱʹ��
		}
	}
	switch (key)
	{
	case 'w':case'W': case 72://����
		MoveLogic(-2, 0);
		break;
	case 'S':case 's':case 80://����
		MoveLogic(2, 0);
		break;
	case 'A':case 'a':case 75://����
		MoveLogic(0, -2);
		break;
	case 'D':case 'd':case 77://����
		MoveLogic(0, 2);
		break;
	case 'R':case'r':
		for (int i = 0; i < 20; i++)
		{
			for (int j = 0; j < 22; j++)
			{
				map[level][i][j] = map_R[i][j];
				map_Z[i][j] = map_R[i][j];
				map_m[i][j] = 0;
			}
		}
		getPos();
		system("cls");
		//draw();
		time = -1;
		flagX = -11;
		break;
	case 'Z':case 'z':
		if (time == 0 || recall == true)
			break;
		else
		{
			recall = true;
			for (int i = 0; i < 20; i++)
			{
				for (int j = 0; j < 22; j++)
				{
					map[level][i][j] = map_Z[i][j];
				}
			}
			getPos();
			draw();
			if (flagX != posx || flagY != posy)
				time -= 2;
		}
		break;
	default:
		break;
	}
	return false;

}

bool gameWin()//��Ϸ���
{
	int temp = 0;
	for (int i = 0; i < 20; i++)
		for (int j = 0; j < 22; j++)
			if (4 == map[level][i][j])
				temp++;
	if (temp == 0)
	{
		if (level == 4)
		{
			system("CLS");
			cout << "zero-����!" << endl;
			cout << "zero-������nb������" << endl;
			system("pause");
			return true;
		}
		else
		{
			cout << "zero-���꣡����" << endl;
			cout << "N��������һ��" << endl;
			char num = _getch();
			while ('n' != num && 'N' != num)
			{
				num = _getch();
			}
			if ('n' == num || 'N' == num)
			{
				level++;
				recall = true;
				for (int i = 0; i < 20; i++)
				{
					for (int j = 0; j < 22; j++)
					{
						map_R[i][j] = map[level][i][j];
						map_m[i][j] = 0;
					}
				}
				getPos();
				time = 0;
				flagX = posx;//��ԭʼλ�õ�X���걸��
				flagY = posy;//��ԭʼλ�õ�Y���걸��
				system("CLS");
				draw();
			}
		}
	}
	return false;
}

/*��Ϸ����
 *ʱ�䣺2019-5-1
 *�༭�ߣ�Zero_Justdoit
 */
void GameControl()
{
	getPos();
	while (1)
	{
		flagX = posx;//��ԭʼλ�õ�X���걸��
		flagY = posy;//��ԭʼλ�õ�Y���걸��
		draw();
		if (gameWin())
			exit(0);
		if (move())
			exit(0);
	}
}
